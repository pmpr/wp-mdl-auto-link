<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680567ac95109             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
