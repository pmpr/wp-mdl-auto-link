<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689750130498b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
