<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689ba6e31b9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
