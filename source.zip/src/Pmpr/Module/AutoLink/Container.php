<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63e2301ab8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
