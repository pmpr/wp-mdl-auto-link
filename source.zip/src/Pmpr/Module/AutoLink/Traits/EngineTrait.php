<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689b491540fea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink\Traits; use Pmpr\Module\AutoLink\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
