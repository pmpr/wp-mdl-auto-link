<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689750130498b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink\Traits; use Pmpr\Module\AutoLink\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
