<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689bb29ab3874             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink\Traits; use Pmpr\Module\AutoLink\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
