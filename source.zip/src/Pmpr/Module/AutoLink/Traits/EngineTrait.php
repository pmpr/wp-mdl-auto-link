<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e81bcc38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink\Traits; use Pmpr\Module\AutoLink\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
