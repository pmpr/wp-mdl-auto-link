<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6838de11c5cf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AutoLink\Traits; use Pmpr\Module\AutoLink\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
