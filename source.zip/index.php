<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689c815ba574c             |
    |_______________________________________|
*/
 use Pmpr\Module\AutoLink\AutoLink; AutoLink::symcgieuakksimmu();
