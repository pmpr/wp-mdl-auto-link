<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689bb29ab3874             |
    |_______________________________________|
*/
 use Pmpr\Module\AutoLink\AutoLink; AutoLink::symcgieuakksimmu();
