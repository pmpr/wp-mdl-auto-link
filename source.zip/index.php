<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689a2bf27a4a2             |
    |_______________________________________|
*/
 use Pmpr\Module\AutoLink\AutoLink; AutoLink::symcgieuakksimmu();
