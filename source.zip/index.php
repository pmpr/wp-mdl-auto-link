<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689750130498b             |
    |_______________________________________|
*/
 use Pmpr\Module\AutoLink\AutoLink; AutoLink::symcgieuakksimmu();
