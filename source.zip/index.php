<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689c59a3174e1             |
    |_______________________________________|
*/
 use Pmpr\Module\AutoLink\AutoLink; AutoLink::symcgieuakksimmu();
